// commentsModel.js
class CommentsModel {
    constructor() {
        this.comments = [];
    }

    getAllComments() {
        return this.comments;
    }

    addComment(comment) {
        this.comments.push(comment);
    }

    editComment(index, newComment) {
        this.comments[index] = newComment;
    }

    deleteComment(index) {
        this.comments.splice(index, 1);
    }
}

module.exports = CommentsModel;