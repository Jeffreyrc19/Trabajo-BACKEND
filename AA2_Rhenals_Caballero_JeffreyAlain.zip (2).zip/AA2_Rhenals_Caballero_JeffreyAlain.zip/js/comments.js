const Comments = {
    // Obtener todos los comentarios
    getAllComments: function() {
        return JSON.parse(window.sessionStorage.getItem('comentarios')) || [];
    },

    // Agregar un nuevo comentario
    addComment: function(comment) {
        let comments = this.getAllComments();
        comments.push(comment);
        window.sessionStorage.setItem('comentarios', JSON.stringify(comments));
    },

    // Restablecer los comentarios a vacío
    resetComments: function() {
        window.sessionStorage.removeItem('comentarios');
    }
};

export default Comments;


