const imageContainer = document.querySelector('.image-container');
const imageItems = document.querySelectorAll('.image-item');
const selectedImageContainer = document.querySelector('.selected-image-container');
const closeButton = document.querySelector('.close-button');
const selectedImage = document.querySelector('.selected-image');

imageItems.forEach((item) => {
    item.addEventListener('click', () => {
        const imgSrc = item.src;
        selectedImage.src = imgSrc;
        selectedImageContainer.classList.add('visible');
    });
});

closeButton.addEventListener('click', () => {
    selectedImageContainer.classList.remove('visible');
});