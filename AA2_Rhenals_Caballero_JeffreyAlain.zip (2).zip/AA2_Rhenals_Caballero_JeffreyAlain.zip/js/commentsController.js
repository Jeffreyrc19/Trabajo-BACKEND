// commentsController.js
const CommentsModel = require('./commentsModel');
const CommentsView = require('./commentsView');

class CommentsController {
    constructor() {
        this.model = new CommentsModel();
        this.view = new CommentsView();
        this.view.bindAddComment(this.handleAddComment);
        // También puedes vincular otras funciones del controlador con eventos de la vista
    }

    handleAddComment = (comment) => {
        this.model.addComment(comment);
        this.view.renderComments(this.model.getAllComments());
    }

    // Otros métodos del controlador para manejar edición, eliminación, etc.
}

const controller = new CommentsController();
