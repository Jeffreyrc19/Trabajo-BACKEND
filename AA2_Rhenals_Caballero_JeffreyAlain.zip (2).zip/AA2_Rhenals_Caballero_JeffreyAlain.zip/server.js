// server.js
const express = require('express');
const mongoose = require('mongoose');
const comentariosRouter = require('./routes/comentarios');

const app = express();

// Conectar a la base de datos MongoDB
mongoose.connect('mongodb://localhost:27017/tu_base_de_datos', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Middleware para manejar datos en formato JSON
app.use(express.json());

// Rutas de la API para comentarios
app.use('/api/comentarios', comentariosRouter);

// Puerto de escucha del servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor escuchando en el puerto ${PORT}`);
});
