document.addEventListener('DOMContentLoaded', () => {
    cargarComentarios(); // Cargar comentarios al cargar la página
});

// Función para cargar comentarios desde el backend y mostrarlos en la interfaz de usuario
async function cargarComentarios() {
    try {
        const response = await fetch('/comentarios');
        if (!response.ok) {
            throw new Error('Error al cargar comentarios');
        }
        const comentarios = await response.json();
        const listaComentarios = document.getElementById('lista-comentarios');
        listaComentarios.innerHTML = ''; // Limpiar la lista de comentarios antes de cargar nuevos comentarios
        comentarios.forEach(comentario => {
            const li = document.createElement('li');
            li.innerHTML = `<strong>${comentario.nombre}:</strong> ${comentario.comentario}
                            <button onclick="editarComentario('${comentario._id}')">Editar</button>
                            <button onclick="eliminarComentario('${comentario._id}')">Eliminar</button>`;
            listaComentarios.appendChild(li);
        });
    } catch (error) {
        console.error('Error:', error);
    }
}

// Función para agregar un nuevo comentario
async function agregarComentario(event) {
    event.preventDefault();
    const nombre = document.getElementById('nombre').value;
    const comentario = document.getElementById('comentario').value;
    try {
        const response = await fetch('/comentarios', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nombre, comentario })
        });
        if (!response.ok) {
            throw new Error('Error al agregar comentario');
        }
        cargarComentarios(); // Recargar la lista de comentarios después de agregar uno nuevo
    } catch (error) {
        console.error('Error:', error);
    }
}

// Función para editar un comentario
async function editarComentario(id) {
    const nuevoComentario = prompt('Ingrese el nuevo comentario:');
    if (nuevoComentario === null || nuevoComentario.trim() === '') {
        return; // Si el usuario cancela o ingresa un comentario vacío, no hacer nada
    }
    try {
        const response = await fetch(`/comentarios/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ comentario: nuevoComentario })
        });
        if (!response.ok) {
            throw new Error('Error al editar comentario');
        }
        cargarComentarios(); // Recargar la lista de comentarios después de editar uno
    } catch (error) {
        console.error('Error:', error);
    }
}

// Función para eliminar un comentario
async function eliminarComentario(id) {
    if (!confirm('¿Estás seguro de que deseas eliminar este comentario?')) {
        return; // Si el usuario cancela la confirmación, no hacer nada
    }
    try {
        const response = await fetch(`/comentarios/${id}`, {
            method: 'DELETE'
        });
        if (!response.ok) {
            throw new Error('Error al eliminar comentario');
        }
        cargarComentarios(); // Recargar la lista de comentarios después de eliminar uno
    } catch (error) {
        console.error('Error:', error);
    }
}

// Agregar un event listener al formulario para agregar comentarios
document.getElementById('nuevo-comentario-form').addEventListener('submit', agregarComentario);
